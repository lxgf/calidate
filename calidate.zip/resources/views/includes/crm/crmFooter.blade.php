<footer class="crm-footer">
    <link rel="stylesheet" href="{{asset('/assets/styles/crm/crm-footer.css')}}">

    <div class="crm-footer__date">
        <?= date('l \t\h\e jS') ?>
    </div>
</footer>
