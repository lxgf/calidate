<div class="overlay">
    <link rel="stylesheet" href="{{asset('/assets/styles/crm/crm-ol.css')}}">
    <div class="overlay__circle"></div>
    <div class="overlay__text overlay-text"></div>
</div>
