<footer>
    footer
</footer>
<?php /**PATH D:\Projects\calidate\resources\views/includes/cmsfooter.blade.php ENDPATH**/ ?>