<!DOCTYPE html>
<html lang="ru">

<head>
    <title>Calidate CMS</title>
    <meta charset="utf-8"/>
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('/assets/styles/reset.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/assets/styles/crm/crm-main.css')); ?>">
</head>

<body>
<noindex>
    <div class="wrapper">
        <?php echo $__env->make('includes.cms.cmsHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <?php echo $__env->make('includes.cms.cmsFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</noindex>
</body>
</html>
<?php /**PATH D:\Projects\calidate\resources\views/layouts/cms.blade.php ENDPATH**/ ?>
