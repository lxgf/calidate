<header>
    header
</header>
<?php /**PATH D:\Projects\calidate\resources\views/includes/cmsHeader.blade.php ENDPATH**/ ?>