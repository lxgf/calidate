<header class="crm-header">
    <link rel="stylesheet" href="<?php echo e(asset('/assets/styles/crm/crm-header.css')); ?>">

    <h1 class="crm-header__heading">
        Calidate CRM
    </h1>
    <p class="crm-header__page">
        ->
        <?php if(Request::path() == 'crm'): ?>
            Заявки клиентов
        <?php endif; ?>
        <?php if(Request::path() == 'crm/login'): ?>
            Вход
        <?php endif; ?>
    </p>
</header>
<?php /**PATH D:\Projects\calidate\resources\views/includes/crm/crmHeader.blade.php ENDPATH**/ ?>