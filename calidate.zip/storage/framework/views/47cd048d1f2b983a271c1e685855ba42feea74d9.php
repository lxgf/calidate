<!DOCTYPE html>
<html lang="ru">

<head>
    <title>
        <?php switch(Request::segment(1)):
            case ('prices'): ?>
                Цены
            <?php break; ?>
            <?php case ('works'): ?>
                Работы
            <?php break; ?>
            <?php case ('techs'): ?>
                Технологии
            <?php break; ?>
            <?php default: ?>
                Главная
        <?php endswitch; ?>
        — Calidate
    </title>
    <meta charset="utf-8" />
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="description" content="
        <?php switch(Request::segment(1)):
            case ('prices'): ?>
                Цены на услуги по разработке сайтов
            <?php break; ?>
            <?php case ('works'): ?>
                Работы коллектива Calidate
            <?php break; ?>
            <?php case ('techs'): ?>
                Технологии, которые мы используем
            <?php break; ?>
            <?php default: ?>
                Команда разработки web-приложений Calidate
        <?php endswitch; ?>
    ">
    <link rel="stylesheet" href="<?php echo e(asset('/assets/styles/reset.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/assets/styles/index.css')); ?>">
    <script defer src="<?php echo e(asset('/assets/libs/jquery-3.6.0.min.js')); ?>"></script>
    <script defer src="<?php echo e(asset('/assets/scripts/hamburger.js')); ?>"></script>
</head>
<body>
    <div class="wrapper">
        <?php echo $__env->make('includes.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <main class="main">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>
</html>
<?php /**PATH D:\Projects\calidate\resources\views/layouts/default.blade.php ENDPATH**/ ?>