<?php $__env->startSection('content'); ?>
    <div class="crm-login">
        <link rel="stylesheet" href="<?php echo e(asset('/assets/styles/crm/crm-login.css')); ?>">
        <script defer src="<?php echo e(asset('/assets/scripts/crm/viewError.js')); ?>"></script>

        <?php echo $__env->make('includes.crm.overlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <form action="<?php echo e(route('loginAction')); ?>" method="POST" class="crm-login-form">
            <?php echo e(csrf_field()); ?>


            <input type="hidden" name="error" value="<?php echo e(Session::get('error')); ?>" class="error">

            <label class="crm-login-form__label">
                Логин
                <input required type="email" name="email" class="crm-login-form__input crm-login-form__email"
                       value="<?php echo e(old('email')); ?>">
            </label>
            <label class="crm-login-form__label">
                Пароль
                <input required type="password" name="password" class="crm-login-form__input crm-login-form__pwd">
            </label>

            <button class="crm-login-form__btn login">
                Зайти
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\calidate\resources\views/pages/crm/crmLogin.blade.php ENDPATH**/ ?>