<header class="cms-header">
    <link rel="stylesheet" href="<?php echo e(asset('/assets/styles/cms/cms-header.css')); ?>">

    <h1 class="cms-header__heading">
        Calidate CMS
    </h1>
    <p class="cms-header__page">
        Заявки клиентов
    </p>
</header>
<?php /**PATH D:\Projects\calidate\resources\views/includes/cms/cmsHeader.blade.php ENDPATH**/ ?>