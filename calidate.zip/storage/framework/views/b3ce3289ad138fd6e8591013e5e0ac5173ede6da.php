<?php $__env->startSection('content'); ?>
    <div class="cms-leads">
        <link rel="stylesheet" href="<?php echo e(asset('/assets/styles/cms/cms-leads.css')); ?>">

        <div class="cms-leads__row cms-head">
            <p class="cms-leads__cell cms-head__name">
                Имя
            </p>
            <p class="cms-leads__cell cms-head__surname">
                Фамилия
            </p>
            <p class="cms-leads__cell cms-head__email">
                Почта
            </p>
            <p class="cms-leads__cell cms-head__page">
                Страница
            </p>
            <p class="cms-leads__cell cms-head__created-at">
                Создан
            </p>
        </div>
        <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="cms-leads__row cms-lead">
                <input type="text" class="cms-leads__cell cms-leads__input cms-lead__name" value="<?php echo e($lead->name); ?>">
                <input type="text" class="cms-leads__cell cms-leads__input cms-lead__surname" value="<?php echo e($lead->surname); ?>">
                <input type="text" class="cms-leads__cell cms-leads__input cms-lead__email" value="<?php echo e($lead->email); ?>">
                <input type="email" class="cms-leads__cell cms-leads__input cms-lead__page" value="<?php echo e($lead->email); ?>">
                <input type="datetime-local" class="cms-leads__cell cms-leads__input cms-lead__created-at" value="<?php echo e($lead->created_at); ?>">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\calidate\resources\views/pages/cms/leadsList.blade.php ENDPATH**/ ?>