<div class="overlay">
    <link rel="stylesheet" href="<?php echo e(asset('/assets/styles/crm/crm-ol.css')); ?>">
    <div class="overlay__circle"></div>
    <div class="overlay__text overlay-text"></div>
</div>
<?php /**PATH D:\Projects\calidate\resources\views/includes/crm/overlay.blade.php ENDPATH**/ ?>