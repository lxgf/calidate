<?php $__env->startSection('content'); ?>
    <div class="crm-leads">
        <button class="crm-leads__create-btn create-lead">+</button>

        <link rel="stylesheet" href="<?php echo e(asset('/assets/styles/crm/crm-leads.css')); ?>">
        <script defer src="<?php echo e(asset('/assets/scripts/crm/leads.js')); ?>"></script>

        <div class="crm-leads__row crm-head">
            <p class="crm-leads__cell crm-head__name">
                Имя
            </p>
            <p class="crm-leads__cell crm-head__surname">
                Фамилия
            </p>
            <p class="crm-leads__cell crm-head__email">
                Почта
            </p>
            <p class="crm-leads__cell crm-head__page">
                Страница
            </p>
            <p class="crm-leads__cell crm-head__created-at">
                Создан
            </p>
        </div>
        <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="crm-leads__row crm-lead" data-id="<?php echo e($lead->id); ?>">
                <div class="crm-lead-ol">
                    <button class="crm-lead-ol__remove-btn remove-lead">
                        ✕
                    </button>
                </div>

                <input type="text" class="crm-leads__cell crm-leads__input crm-lead__name" data-col="name" value="<?php echo e($lead->name); ?>">
                <input type="text" class="crm-leads__cell crm-leads__input crm-lead__surname" data-col="surname" value="<?php echo e($lead->surname); ?>">
                <input type="text" class="crm-leads__cell crm-leads__input crm-lead__email" data-col="email" value="<?php echo e($lead->email); ?>">
                <input type="email" class="crm-leads__cell crm-leads__input crm-lead__page" data-col="page" value="<?php echo e($lead->page); ?>">
                <p class="crm-leads__cell crm-lead__created-at" data-col="created_at">
                    <?php echo e($lead->created_at); ?>

                </p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.crm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\calidate\resources\views/pages/crm/leadsList.blade.php ENDPATH**/ ?>