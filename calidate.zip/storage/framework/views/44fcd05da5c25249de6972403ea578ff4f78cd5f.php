<!DOCTYPE html>
<html lang="ru">

<head>
    <title>Calidate CRM</title>
    <meta charset="utf-8"/>
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('/assets/styles/reset.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/assets/styles/crm/crm-main.css')); ?>">
    <script defer src="<?php echo e(asset('/assets/libs/jquery-3.6.0.min.js')); ?>"></script>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>

<body>
<noindex>
    <div class="wrapper">
        <?php echo $__env->make('includes.crm.crmHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <?php echo $__env->make('includes.crm.crmFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</noindex>
</body>
</html>
<?php /**PATH D:\Projects\calidate\resources\views/layouts/crm.blade.php ENDPATH**/ ?>